﻿using System.Windows;
using System.Windows.Controls;

namespace WpfApp1
{
    public partial class Result : Page
    {
        public Result(int correctCount, int totalCount)
        {
            InitializeComponent();
            txtResult.Text = $"Правильных ответов: {correctCount} из {totalCount}";
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();

            Window window = Window.GetWindow(this);
            window.Close();
        }
    }
}